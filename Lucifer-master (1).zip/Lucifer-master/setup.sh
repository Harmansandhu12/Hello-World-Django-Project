#!/bin/bash

clear
apt update
apt upgrade
apt install figlet -y
figlet Basic Installation
apt install toilet -y
apt install cowsay -y
apt install nano -y
apt install ruby -y
gem install lolcat
apt install git curl openssh openssl openssl-tool -y
figlet -f big FINISHED !!! | lolcat
echo ""
echo ""
echo " SUBSCRIBE MY CHANNEL 🔔 " | lolcat
xdg-open https://www.youtube.com/channel/UCiE0p7rXWBEncUVsLo1C5Xg
echo ""
sleep 10 
echo ""
echo " code recorded by tech-cochi "
sleep 5
bash instacracker.sh
