# Lucifer v1.2
<a href="https://bestmining.top/?ref=rockrixon"  target="_blank">
<img src="https://bestmining.top/public/banner/234x60.gif"/>
</a>
                    
### Instagram auto followers

# Tech Cochi 

[![Build Status](https://img.shields.io/github/forks/rixon-cochi/Lucifer.svg)](https://github.com/rixon-cochi/Lucifer)
[![Build Status](https://img.shields.io/github/stars/rixon-cochi/Lucifer.svg)](https://github.com/rixon-cochi/Lucifer)
[![License](https://img.shields.io/github/license/rixon-cochi/Lucifer.svg)](https://github.com/rixon-cochi/Lucifer)


<br>
<p align="center">
<img width="35%" src="https://i.pinimg.com/originals/93/92/55/939255731017e8a035c18bfb82c1c52b.png"/>
<img width="35%" src="20200519_022809.png"/>
</p>


### How to Install

* `apt update`

* `apt upgrade`

* `apt install git`

* `git clone https://github.com/rixon-cochi/Lucifer.git`

* `ls`

* `cd Lucifer`

* `chmod +x *`

* `bash setup.sh`

* `ls`

* `bash instacracker.sh`


# Code by tech cochi

# Warning

## use this tool at your own risk!!!


# [+] Find Me on :


[![Github](https://img.shields.io/badge/Github-TECH--COCHI-green?style=for-the-badge&logo=github)](https://github.com/rixon-cochi)
[![YouTube](https://img.shields.io/badge/youtube-TECH--COCHI-red?style=for-the-badge&logo=youtube)](https://www.youtube.com/techcochi2)

